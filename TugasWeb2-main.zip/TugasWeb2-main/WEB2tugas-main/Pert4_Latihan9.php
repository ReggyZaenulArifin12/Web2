<?php
   $arr=array("senin", "selasa", "rabu");
	foreach ($arr as $hari){
	echo "Hari: " . $hari . "<br>";
	}
?>