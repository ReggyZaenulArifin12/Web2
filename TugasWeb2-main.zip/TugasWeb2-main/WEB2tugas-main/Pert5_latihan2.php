<?php
$file = fopen("Pert5_latihan1.php","r");
echo fgets($file);
fclose($file);
?> 