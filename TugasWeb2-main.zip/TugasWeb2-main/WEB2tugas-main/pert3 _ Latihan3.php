<?php 
    $destination = "Tokyo";
    switch ($destination) {
        case "las Vegas":
            echo "Bring an Extra $500";
            break;
        case "Amsterdam":
            echo "Bring an open mind";
            break;
        case "Egypt":
            echo "Bring 15 bottle of SPF 50 Sunscreen";
            break;
        case "Tokyo":
            echo "Bring lots of Money";
            break;
        case "Carrabean Islands":
            echo "Bring a Swimsuit";
            break;
    }
?>
